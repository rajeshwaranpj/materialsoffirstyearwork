﻿function mypat()
{
    var highs = Math.floor(document.getElementById("high").value);
    var perm = highs;
    var ele = "";
    var time = "";
    for(var iter1=perm;iter1>0;iter1--){
        for (var iter2 = perm; iter2 >iter1; iter2--) {
            ele += "-" ;
        }
        for (var iter = 1; iter <= iter1; iter++) {
            ele = ele + iter.toString();
        }
        ele += "\n";
    }
    alert(""+ele);
}