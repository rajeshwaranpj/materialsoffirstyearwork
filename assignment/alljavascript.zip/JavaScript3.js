﻿function gets()
{
    var mins = Math.floor( document.getElementById("mini").value);
    var maxs = Math.floor(document.getElementById("maxi").value);
    var count = 0;
    var temp;
    var rem;
    for (var iter = mins; iter <= maxs; iter++){
        temp = iter;
        if(temp==1)
            count += 1;
        else {
            while (temp > 1) {
                rem = Math.floor(temp % 10);
                if (rem == 1)
                    count += 1;
                temp =Math.floor( temp / 10);
            }
            if (temp == 1)
                count += 1;
        }
    }
    alert("total 1's in the range are " + count);
}