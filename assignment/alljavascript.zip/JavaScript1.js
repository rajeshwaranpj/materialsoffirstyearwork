﻿function Palindrome() {
    var reverseStr = "";
    var mystr = document.getElementById("str").value;
    var iter = mystr.length;
    for (var pos = 0; pos < iter; pos++) {
        reverseStr = mystr.charAt(pos)+reverseStr ;
    }
    if (mystr == reverseStr) {
        alert("It is Palindrome");
        document.getElementById("str").value = "";
    }
    else {
        alert("It is not a Palindrome");
        document.getElementById("str").value = "";
    }
}
function binary()
{
    var mynum = document.getElementById("str").value;
    if(isNaN(mynum))
    {
        alert("Enter a Valid number");
        document.getElementById("str").value = "";
    }
    else {
        var iter = mynum.length;
        var output = "it is a binary number";
        for (var pos = 0; pos < iter; pos++)
        {
            if (mynum.charAt(pos) != '0' && mynum.charAt(pos) != '1')
            {
                output = "It is not a binary number";
                break;
            }
        }
        alert(""+output);
    }
}
function upperCase()
{
    var name = document.getElementById("str").value;
    var Uname = name.toUpperCase();
    alert("Upper Case :" + Uname);
}


